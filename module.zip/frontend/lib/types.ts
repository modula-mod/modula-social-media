export type SocialModuleRoute = '/social';
